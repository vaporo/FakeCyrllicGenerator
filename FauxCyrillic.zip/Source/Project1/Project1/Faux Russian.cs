﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project1
{
    class FauxRussian
    {
        static void Main()
        {
            string RunDir;
            string SwapDir;
            string InputDir;
            string OutputDir;
            string[] SwapLines;
            string[][] Swaps;
            int NumSwaps;
            int RandSelect;
            string Swapto;
            string[] AllRunDirFiles;
            string SwapFileBase="SwapSheet";
            Random RandNum = new Random();
            Boolean DidReplace = false;
            string OutputFile="";
            string SwapsheetUserInput = "1";
            //string InHold;
            RunDir = AppDomain.CurrentDomain.BaseDirectory;
            InputDir = RunDir + "Input.txt";
            OutputDir = RunDir + "Output.txt";
            AllRunDirFiles = Directory.GetFiles(RunDir);
            string[] AllSwapSheets= new string[AllRunDirFiles.Length];
            int l=0;
            foreach (string Dir in AllRunDirFiles)
            {
                if (SwapFileBase.ToLower() == Dir.Substring(RunDir.Length, SwapFileBase.Length).ToLower() && ".txt"==Dir.Substring(Dir.Length-4))
                {
                    AllSwapSheets[l]=Dir;
                    l++;
                }
            }
            int NumSwapSheetsFound = l;
            if (NumSwapSheetsFound>1)
            {
                l = 0;
                Console.WriteLine("Multiple Swap Sheets were detected. Please input a number from the following list to indicate which sheet you would like to use:\n");
                do
                {
                    if (SmartCint(SwapsheetUserInput) <= 0 || SmartCint(SwapsheetUserInput) > NumSwapSheetsFound)
                    {
                        Console.WriteLine("Moron! You entered an inappropriate value. If the programmer weren't so intelligent and handsome, the program could have CRASHED!");
                    }
                    while (l < AllSwapSheets.Length)
                    {
                        if (AllSwapSheets[l] != null && AllSwapSheets[l] != "")
                        {
                            Console.WriteLine((l + 1).ToString() + ": " + AllSwapSheets[l].Substring(RunDir.Length));
                        }
                        l++;
                    }
                    SwapsheetUserInput = Console.ReadLine();
                } while ((SmartCint(SwapsheetUserInput) > NumSwapSheetsFound || SmartCint(SwapsheetUserInput) <= 0));
            }
            else if (NumSwapSheetsFound==0)
            {
                Console.WriteLine("No Swap Sheets were present in the file. Please read the Readme.txt provided with this program for usage instructions. Press any key to quit.");
                Console.ReadKey();
                return;
            }
            Console.WriteLine("Translating input.\n");
            SwapDir = RunDir + AllSwapSheets[SmartCint(SwapsheetUserInput)-1].Substring(RunDir.Length);

            string SwapFile = File.ReadAllText(SwapDir, Encoding.Unicode);
            SwapLines = SwapFile.Split('\n');
            Swaps = new String[SwapLines.Length][];
            for (int i = 0 ; i<SwapLines.Length ; i++)
            {
                try
                {
                    Swaps[i] = SwapLines[i].Split(' ', '	');
                }
                catch
                { }
            }
            string test = Swaps[7][1];
            string InputFile = File.ReadAllText(InputDir, Encoding.Unicode);
            int j = 0;
            while (j < InputFile.Length)
                {
                int k=0;
                //Console.WriteLine(j.ToString());
                while (k < Swaps.GetLength(0))
                    {
                        DidReplace = false;
                        try
                        {
                            if (InputFile.Substring(j, Swaps[k][0].Length).ToLower() == Swaps[k][0].ToLower() && Swaps[k][0].ToLower() != null && Swaps[k][0].ToLower() != "" && Swaps[k][1].ToLower() != null && Swaps[k][1].ToLower() != "")
                            {
                                NumSwaps = Swaps[k].Length - 1;
                                RandSelect=RandNum.Next(0, NumSwaps);
                                Swapto = Swaps[k][1 + RandSelect];
                                OutputFile = OutputFile + Swapto;
                                test = Swaps[k][1];
                                j = j + Swaps[k][0].Length - 1;
                                DidReplace = true;
                                break;
                            }
                        }
                        catch { }
                        k = k + 1;
                    }
                    if (! DidReplace)
                    {
                        OutputFile = System.String.Concat(OutputFile, InputFile.Substring(j, 1));
                    }
                    j=j+1;
                }
            StreamWriter WriteOutput = new StreamWriter(OutputDir, false, Encoding.Unicode);
            WriteOutput.Write(OutputFile);
            WriteOutput.Close();
            Console.WriteLine("Translation successful! Output was written to: \n \n"+OutputDir+"\n\nPress any key to continue.");
            Console.ReadKey();
        }
        static int SmartCint(string input)
        {
            try
            {
                return Convert.ToInt32(input);
            }
            catch
            {
                return 0;
            }
        }
    }
}
