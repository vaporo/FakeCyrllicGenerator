Faux Cyrillic Translator usage instructions:

This program is a simple "Translator" for generating Faux Cyrillic (Or Faux anything, really) with
configurable outputs.

This program simply takes all of the text in the Unicode Input.txt file located alongside this Readme and,
based on a character swap sheet also located alongside this Readme, swaps out letters or letter 
combinations for Unicode characters.

To use:
0. Copy this file somewhere you can remember it.

1. Create a Swap sheet. The file must be a unicode .txt file starting with "SwapSheet." there are
	three swap sheets included with this program. The letter or letter combination that starts
	each line is the character that will be swapped out. All further characters on the same line
	separated by a SINGLE space will randomly selected to swap with that first letter.
	Perhaps make a backup of one of the swap sheets in case you forget the format.

2. Add the text you want translated to the Input.txt file. The file must be saved with Unicode encoding.
	The example Input.txt is encoded as Unicode by default, so you should probably only ever need
	to edit	and resave it.

3. Run FauxCyrillic.exe from the same file as the Input.txt and swap sheets.

4. If you have multiple swap sheets (which this program comes with by default), an option to select 
	between them will appear. Enter the number next to the swap sheet that you want to use and
	press enter.

5. The results will be written to Output.txt in the same file.

Notes:
Everything must be located in the same directory.
All text files should use Unicode encoding.
Be sure you have copied everything you want out of Output.txt before rerunning. The program will
	overwrite Output.txt when it runs.